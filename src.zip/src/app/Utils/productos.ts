export interface Productos {
    id: any;
    nombre: string;
    marca: string;
    modelo: string;
    precio: number;
    imagen: string;
    detalles: string;
}