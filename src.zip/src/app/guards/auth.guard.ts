import { CanActivateFn } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  //VERFICA SI EL USUARIO NO HA INICIADO SESION
  if (localStorage.getItem('login') !== 'true') {
    //SE BLOQUEA SI NO SE HA LOGUEADO
    return false;
  } else {
    //PERMITE EL ACCESO
    return true;
  }
};
